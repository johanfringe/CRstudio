// /src/pages/register.js:
import React, { useState, useEffect } from "react";
import { graphql, navigate } from "gatsby";
import { useTranslation } from "gatsby-plugin-react-i18next";
import { useI18next } from "gatsby-plugin-react-i18next";
import { validateEmail } from "../utils/emailValidator";
import { supabase } from "../lib/supabaseClient";
import { Button, Input } from "../components/ui";
import Seo from "../components/Seo";
import SectionWrapper from "../components/SectionWrapper";
import { log, warn, error, captureApiError } from "../utils/logger";
import { waitForSession } from "../utils/session";

const Register = () => {
  const { t } = useTranslation();
  const { language } = useI18next();

  const [email, setEmail] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [loading, setLoading] = useState(false);
  const [turnstileToken, setTurnstileToken] = useState(null);

  // Laad Cloudflare Turnstile correct
  useEffect(() => {
    const loadTurnstileScript = () => {
      if (!window.turnstile) {
        const script = document.createElement("script");
        script.src = "https://challenges.cloudflare.com/turnstile/v0/api.js";
        script.async = true;
        script.onload = () => {
          log("✅ Turnstile script geladen!", { loaded: true });
          window.turnstile.render("#turnstile-container", {
            sitekey: process.env.GATSBY_TURNSTILE_SITE_KEY,
            callback: (token) => {
              log("✅ Turnstile Token ontvangen", { token });
              setTurnstileToken(token);
            },
          });
        };
        document.body.appendChild(script);
      } else {
        window.turnstile.render("#turnstile-container", {
          sitekey: process.env.GATSBY_TURNSTILE_SITE_KEY,
          callback: (token) => {
            log("✅ Turnstile Token ontvangen", { token });
            setTurnstileToken(token);
          },
        });
      }
    };

    loadTurnstileScript();
  }, []);

  // 🌍 Social Login handler
  const handleSocialLogin = async (provider) => {
    try {
      log("🔗 Start social login met provider", { provider });
      setLoading(true);
      setErrorMsg("");

      const redirectTo = `${window.location.origin}/${language}/profile`;
      log("🔁 Instellen redirectTo voor fallback", { redirectTo });

      const { data, error: loginError } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          popup: true,
          pkce: true,
          redirectTo,
          queryParams: {
            access_type: "offline",
            prompt: "consent",
          },
        },
      });

      log("📦 OAuth data", { data });

      if (loginError) {
        error("❌ Social login fout", { loginError });

        if (loginError.message.toLowerCase().includes("popup")) {
          setErrorMsg("Popup werd geblokkeerd of gesloten. Probeer opnieuw.");
        } else {
          setErrorMsg(loginError.message);
        }
        return;
      }

    // ⏳ Wacht kort tot de sessie effectief beschikbaar is
      const session = await waitForSession();
      if (!session) {
        warn("⚠️ Geen sessie na social login. Popup gesloten of vertraagd", { location: window.location.href, provider });
        return;
      }

      log("✅ Supabase sessie succesvol", { session });
      log("➡️ Navigeren naar profielpagina", { language });
      navigate(`/${language}/profile`);
    } catch (err) {
      error("❌ Onverwachte fout bij social login", { err });
    } finally {
      setLoading(false);
    }
  };

  // 📩 Formulier submit handler voor e-mailregistratie
  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg("");

    if (!validateEmail(email)) {
      warn("⚠️ Ongeldig e-mailadres bij registratie", { email });
      setErrorMsg(t("register.email_invalid"));
      return;
    }

    warn("⚠️ Geen Turnstile-token beschikbaar bij submit", { email });
    if (!turnstileToken) {
      setErrorMsg(t("register.check"));
      return;
    }

    setLoading(true);

    try {
      log("📡 Versturen van registratieverzoek voor e-mail", { email });
      log("📬 Verzenden fetch /api/register", { email, turnstileToken, lang: language });
      const response = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, turnstileToken, lang: language }),
      });

      const data = await response.json();

      const errorCode = data.code || "UNKNOWN_ERROR";
      captureApiError("/api/register", response, { errorCode, data, email });
    
      // 👇 VERBETERDE EMAIL_DUPLICATE FLOW
      if (errorCode === "EMAIL_DUPLICATE") {
        try {
          const { data: sessionData } = await supabase.auth.getSession();
          const userId = sessionData?.session?.user?.id;
    
          if (userId) {
            const { data: profile, error: profileError } = await supabase
              .from("profiles")
              .select("subdomain")
              .eq("id", userId)
              .maybeSingle();
    
            if (profileError) {
              warn("⚠️ Fout bij ophalen profiel", { profileError });
            }
    
            if (profile?.subdomain) {
              setErrorMsg(
                t("register.account_exists_subdomain") +
                  ` 👉 https://${profile.subdomain}.crstudio.online/account`
              );
            } else {
              setErrorMsg(t("register.account_exists_no_subdomain"));
            }
          } else {
            setErrorMsg(t("register.verify_error.EMAIL_DUPLICATE"));
          }
        } catch (err) {
          warn("⚠️ Fout bij afhandeling EMAIL_DUPLICATE", { err });
          setErrorMsg(t("register.verify_error.EMAIL_DUPLICATE"));
        }
    
        return;
      }
    
      // Standaard fallback bij andere fouten
      setErrorMsg(t(`register.verify_error.${errorCode}`) || t("register.UNKNOWN_ERROR"));
      return;

      log("✅ Registratie succesvol", { data });
      alert(t("register.succes"));
    } catch (err) {
      error("❌ Registratiefout", { err, email });
      setErrorMsg(err.message);
    } finally {
      setLoading(false);

      // 🔁 Reset Turnstile na submit (zowel bij fout als succes)
      if (window.turnstile) {
        log("🔁 Turnstile wordt opnieuw gerenderd", { reset: true });
        window.turnstile.reset("#turnstile-container");
        setTurnstileToken(null);
      }
    }
  };

  return (
    <>
      <Seo
        title={t("register.seo_title", { defaultValue: t("seo.title") })}
        description={t("register.seo_description", { defaultValue: t("seo.description") })}
      />
      <SectionWrapper bgColor="bg-white">
        <div className="min-h-screen flex justify-center items-start py-24" aria-label={t("register.page_description")}>
          <div className="max-w-xs w-full mx-auto">
            <div className="text-center mb-6">
              <img
                src="/images/CRlogo.jpg"
                alt={t("register.logo_alt")}
                className="h-8 mx-auto"
              />
              <h1 className="text-xl font-semibold mt-16">{t("register.heading")}</h1>
            </div>

            <p className="intro-text">{t("register.intro_text")}</p>

            {/* 🟢 Social Login Sectie */}
            <div className="flex flex-col space-y-3">
              <Button
                onClick={() => handleSocialLogin("google")}
                className="flex items-center justify-center w-full border border-black rounded-lg py-2 text-sm hover:bg-gray-50"
              >
                <img src="/icons/google.svg" alt="Google Logo" className="h-5 w-5 mr-2" />
                {t("register.google_placeholder")}
              </Button>
            </div>

            <div className="my-6 flex items-center">
              <hr className="flex-grow border-gray-300" />
              <span className="px-3 text-gray-700">{t("register.or")}</span>
              <hr className="flex-grow border-gray-300" />
            </div>

            {/* 📩 E-mail registratieformulier */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="email"
                id="email"
                name="email"
                placeholder={t("register.email_placeholder")}
                value={email}
                onChange={(e) => setEmail(e.target.value.trim().toLowerCase())}
                className={`input w-full ${errorMsg ? "input-error" : ""}`}
                aria-invalid={errorMsg ? "true" : "false"}
                aria-describedby={errorMsg ? "email-error" : undefined}
              />
              {errorMsg && (
                <p id="email-error" className="text-red-500 text-xs mt-1">
                  {errorMsg}
                </p>
              )}
              <div id="turnstile-container" className="w-full flex justify-center mt-2"></div>

              <Button type="submit" disabled={loading} className="btn btn-primary w-full">
                {loading ? t("register.button_busy") : t("register.button_register")}
              </Button>
            </form>
          </div>
        </div>
      </SectionWrapper>
    </>
  );
};

export default Register;

export const query = graphql`
  query($language: String!) {
    locales: allLocale(filter: { language: { eq: $language } }) {
      edges {
        node {
          ns
          data
          language
        }
      }
    }
  }
`;
